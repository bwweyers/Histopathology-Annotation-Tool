



function varargout = label_gen_GUI(varargin)
% LABEL_GEN_GUI MATLAB code for label_gen_GUI.fig
%      LABEL_GEN_GUI, by itself, creates a new LABEL_GEN_GUI or raises the existing
%      singleton*.
%
%      H = LABEL_GEN_GUI returns the handle to a new LABEL_GEN_GUI or the handle to
%      the existing singleton*.
%
%      LABEL_GEN_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in LABEL_GEN_GUI.M with the given input arguments.
%
%      LABEL_GEN_GUI('Property','Value',...) creates a new LABEL_GEN_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before label_gen_GUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to label_gen_GUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help label_gen_GUI

% Last Modified by GUIDE v2.5 27-Feb-2019 12:45:16

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @label_gen_GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @label_gen_GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before label_gen_GUI is made visible.
function label_gen_GUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to label_gen_GUI (see VARARGIN)

% Choose default command line output for label_gen_GUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes label_gen_GUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = label_gen_GUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[file,path,indx]=uigetfile;

if file==0
    return;
end

data=load(fullfile(path,file));



set(handles.uitable4,'Data',data.current_data)




% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

answer = questdlg('New or existing tissue class?','Tissue Class',"New","Existing","New");


switch answer
    case 'New'
        name = inputdlg("Enter tissue class name");  
    case 'Existing'
     oldData = get(handles.uitable4,'Data');
     [indx,tf] = listdlg('ListString',oldData(:,2),'SelectionMode','single');
     name=oldData(indx,2);
        
end

answer = questdlg('Include a sub-class label?','Tissue SubClass',"Yes","No","Yes");

switch answer
    case 'Yes'
        sub_class_answer = questdlg('New or existing tissue sub-class?','Tissue Sub-Class',"New","Existing","New");
        switch sub_class_answer
            case 'New'
                sub_class = inputdlg("Enter tissue sub-class name");  
            case 'Existing'
              oldData = get(handles.uitable4,'Data');
            [indx,tf] = listdlg('ListString',oldData(:,3),'SelectionMode','single');
            sub_class=oldData(indx,3) ;
        end  
          
      
    case 'No'
        sub_class="";
   
        
end

if ~strcmp(sub_class,"")

    answer = questdlg('Include a sub-class variant label?','Tissue SubClass',"Yes","No","Yes");

    switch answer
        case 'Yes'
            sub_class_answer = questdlg('New or existing tissue sub-class variant?','Tissue Sub-Class',"New","Existing","New");
            switch sub_class_answer
                case 'New'
                    sub_class_variant = inputdlg("Enter tissue sub-class variant name");  
                case 'Existing'
                  oldData = get(handles.uitable4,'Data');
                [indx,tf] = listdlg('ListString',oldData(:,4),'SelectionMode','single');
                sub_class_variant=oldData(indx,4) ;
            end  


        case 'No'
            sub_class_variant="";


    end
    
else
    sub_class_variant=""';
end




oldData = get(handles.uitable4,'Data');


existing_names=oldData(:,2:4);
new_name=[name  sub_class  sub_class_variant];

for i=1:size(existing_names,1)
   tmp=string(existing_names(i,:));
   
   index = all(cellfun(@strcmp, tmp, new_name));
   
   if index==1
       
       f = msgbox("Tissue Type Already Exists");
      return 
   end
   
   
   
   
end






        


desc = inputdlg("Enter Description");




s=size(oldData);

if s(1) > 0
    current_max=max(cell2mat(oldData(:,1)));
else
    current_max=0;
end



newData = [oldData;{current_max+1,name{1},sub_class{1},sub_class_variant{1},desc{1}}];
set(handles.uitable4,'Data',newData)

function pushbutton5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

function uitable4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(hObject, 'Data', cell(0,5));




% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

current_data = get(handles.uitable4,'Data');

len=size(current_data,1);

Type(1:len)=labelType.PixelLabel;

Type=transpose(Type);


PixelLabelID=current_data(:,1);

Description=current_data(:,5);

[file,path,indx] = uiputfile('labels_export.mat');

if file==0
    return;
end

Name=string(PixelLabelID);

for i= 1:size(Name,1)
    Name(i)=strcat("Class_",Name(i));
    
end


for i=1:size(Description,1)
    string_temp=strcat("Class: ",current_data(i,2)," |Sub-Class: ",current_data(i,3)," |Sub-Class Variant: ",current_data(i,4)," |Description:",string(Description(i)));
    
    Description{i}=string_temp;
end
    


definitions=table(Name,Type,PixelLabelID,Description);


save(fullfile(path,file)',"definitions");


% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 current_data = get(handles.uitable4,'Data');
 PixelLabelID=cell2mat(current_data(:,1));
[indx,tf] = listdlg('ListString',int2str(PixelLabelID),'SelectionMode','single');

current_data(indx,:)=[];

set(handles.uitable4, 'Data', current_data);


% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[file,path,indx] = uiputfile('labels.mat');
if file==0
    return;
end

 current_data = get(handles.uitable4,'Data');
 
 save(fullfile(path,file),"current_data");
