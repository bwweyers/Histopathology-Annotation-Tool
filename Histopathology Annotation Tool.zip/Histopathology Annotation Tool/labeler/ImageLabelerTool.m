% This class is for internal use only and may change in the future.

% ImageLabelerTool Main class for Image Labeler
%
%   To invoke the tool, follow these steps:
%       tool = vision.internal.imageLabeler.tool.ImageLabelerTool;
%       tool.show();

% Copyright 2015-2017 The MathWorks, Inc.

classdef ImageLabelerTool < vision.internal.labeler.tool.LabelerTool
    
    properties(Access = protected,Constant)
        % ToolName Official name of app, e.g Ground Truth Labeler
        ToolName = vision.getMessage('vision:imageLabeler:ToolTitle');
        
        % InstanceName Name used to manage tool instance.
        InstanceName = 'imageLabeler';
        
        % SupportedROILabelTypes Array of ROI labelTypes the app supports.
        % This defines the type of ROIs that are allowed when defining ROI
        % labels.
        SupportedROILabelTypes = [labelType.Rectangle labelType.PixelLabel];
    end
    
    methods(Access = public)
        function this = ImageLabelerTool()
            
            % Generate a temporary, unique name for the tool.
            [~,name] = fileparts(tempname);
            
            this.ToolGroup = matlab.ui.internal.desktop.ToolGroup(...
                this.ToolName, name);
            
            % Build a tab group to hold app tabs.
            this.TabGroup = matlab.ui.internal.toolstrip.TabGroup();
            
            % Add the tab group to the tool group.
            this.ToolGroup.addTabGroup(this.TabGroup);
            
            % Add the main tab to this tab group.
            this.LabelTab       = vision.internal.imageLabeler.tool.LabelTab(this);
            this.SemanticTab    = vision.internal.labeler.tool.SemanticTab(this);
            this.AlgorithmTab   = vision.internal.imageLabeler.tool.AlgorithmTab(this);
            
            % When the app starts up, the Label Tab is active.
            this.ActiveTab = this.LabelTab;
            
            % Add Session Manager
            this.SessionManager = vision.internal.imageLabeler.tool.ImageLabelerSessionManager;
            
            % Create Session
            this.Session = vision.internal.imageLabeler.tool.Session;
            
            % Add Automation Setup manager
            this.AlgorithmSetupHelper = vision.internal.labeler.tool.AlgorithmSetupHelper(this.InstanceName);
            addlistener(this.AlgorithmSetupHelper, 'CaughtExceptionEvent', @(src,evt) this.showExceptionDialog(evt.ME, evt.DlgTitle));
            
            % Add App Figure Managers
            this.GraphicsDisplay        = vision.internal.imageLabeler.tool.LabeledImageBrowserDisplay();
            this.ROILabelSetDisplay     = vision.internal.labeler.tool.ROILabelSetDisplay(this.InstanceName);
            % We need to set the following 'ImageLabeler' tag so that label's expand
            % button can recognize that its parent is ImageLabeler and can
            % avoid displaying attribute edit box. see ROILabelItem.m
            this.ROILabelSetDisplay.Fig.UserData = 'ImageLabeler'; 
            this.FrameLabelSetDisplay   = vision.internal.labeler.tool.FrameLabelSetDisplay(this.InstanceName);
            this.InstructionsSetDisplay = vision.internal.labeler.tool.InstructionsSetDisplay();                     
            
            % Add scene label legend display
            hFig = this.GraphicsDisplay.Fig;
            this.LegendDisplay = vision.internal.labeler.tool.FrameLabelLegendDisplay(hFig);
            
            % Add undo/redo to callbacks quick-access bar
            this.configureQuickAccessBarUndoRedoButton();
            
            % Add doc link
            this.ToolGroup.setContextualHelpCallback(@(es, ed) doc('imageLabeler'));
                
            % Handle closing of the app
            this.setClosingApprovalNeeded(true);
            addlistener(this.ToolGroup, 'GroupAction', @(es,ed)doAppClientActions(this, es, ed));
           
            
            % Add tool to array of instances
            this.addToolInstance();
            
        end
       
        function doLoadLabelDefinitionsFromFile(this,fileName)

            setWaiting(this.ToolGroup, true);
            try
                % Load the MAT-file.
                temp = load(fileName,'-mat');
                
             
                % The MAT-file is expected to return a struct with a single
                % field whose value is of type table.
                fields = fieldnames(temp);
                definitions = temp.(fields{1});
               
                
               %definitions = vision.internal.labeler.validation.checkLabelDefinitions(definitions)
                
               
                
                if ismember('PixelLabelData', definitions.Name)
                     PixelLabelData is reserved for all pixel label ROI.
                    errordlg(...
                        vision.getMessage('vision:labeler:LabelDefContainsPixelLabelDataMsg'),...
                        vision.getMessage('vision:labeler:LabelNameInvalidDlgName'),...
                        'modal');
                    setWaiting(this.ToolGroup, false);
                    return
                elseif any(contains(definitions.Properties.VariableNames, 'Hierarchy'))
                     Hierarchy column is not supported in imageLabeler.
                    errordlg(...
                        vision.getMessage('vision:labeler:HierarchyColumnUnsupported'),...
                        vision.getMessage('vision:labeler:ColumnNameInvalidDlgName'),...
                       'modal');
                    setWaiting(this.ToolGroup, false);
                    return                    
                end                    
                
                % Delete the current definitions
                deleteAllItemsLabelSetDisplay(this);
                
                
                % Update session data
                this.Session.loadLabelDefinitions(definitions);
              
                

            catch  e
                e
                handleLoadDefinitionError(this, fileName, vision.getMessage('vision:imageLabeler:ToolTitle'));
                return;
            end
            
            
            
            
            reconfigureROILabelSetDisplay(this);
            
          
            
            reconfigureFrameLabelSetDisplay(this);
            
           
            
            if hasImages(this.Session)
                % Update Display
                drawImage(this, this.getCurrentIndex(), false);
            end
            
            
            
            
            updateUI(this);
            
            
            setWaiting(this.ToolGroup, false);
            
    
        end         
        
    end
    
    %----------------------------------------------------------------------
    % App Layout
    %----------------------------------------------------------------------
    methods (Access = protected)
        
        %------------------------------------------------------------------
        function configureDisplays(this)
            
            % Configure image display
            configure(this.GraphicsDisplay, ...
                @this.doImageSelected, ...
                @this.doImageRemoved, ...
                @this.doImageRotate, ...
                @this.doLabelIsChanged, ...
                @this.doFigKeyPress, ...
                @this.doModeChange, ...
                @this.doDisableAppForDrawing, ...
                @this.doEnableAppForDrawing, ...
                @this.doStartAppWait, ...
                @this.doFinishAppWait, ...
                @this.doEnableGrabCutEditTools, ...
                @this.doDisableGrabCutEditTools);
            
            % Configure label set display
            configure(this.ROILabelSetDisplay, ...
                @this.doROIPanelItemSelectionCallback, ...
                @this.doROILabelAdditionCallback, ...
                @this.doROISublabelAdditionCallback, ...
                @this.doROIAttributeAdditionCallback, ...
                @this.doROIPanelItemModificationCallback, ...
                @this.doROIPanelItemDeletionCallback, ...
                @this.doFigKeyPress);            
            
            % Configure frame label set display
            configure(this.FrameLabelSetDisplay, ...
                @this.doFrameLabelCallback, ...
                @this.doFrameUnlabelCallback, ...
                @this.doFrameLabelSelectionCallback, ...
                @this.doFrameLabelAdditionCallback, ...
                @this.doFrameLabelModificationCallback, ...
                @this.doFrameLabelDeletionCallback, ...
                @this.doFigKeyPress);
            
        end
        
        %------------------------------------------------------------------
        function updateTileLayout(this, showInstructions, varargin)
            
            % Make sure figures are rendered before tiling
            drawnow;
            
            showAttributes = false;
            updateTileLayout@vision.internal.labeler.tool.LabelerTool(this, showInstructions, showAttributes);
            
        end
        
        %------------------------------------------------------------------
        function updateUI(this)
            
            % Flag which indicates labels exist or not in the app
            anyLabels = this.Session.HasROILabels || this.Session.HasFrameLabels;
            
            if getNumImages(this.Session)
                
                % Enable label tab controls
                enableControls(this.LabelTab);
                enableControls(this.AlgorithmTab);
                enableControls(this.SemanticTab);
                
                % Enable ROI button if needed
                enableROIButton(this.LabelTab,this.Session.HasROILabels);
                enableROIButton(this.SemanticTab,this.Session.HasROILabels);
                enableROIButton(this.AlgorithmTab,this.Session.HasROILabels);
                
                modeSelection = this.LabelTab.getModeSelection;
                this.setMode(modeSelection);                
                
                % Enable Show Label Checkboxes
                enableShowLabelBoxes(this.LabelTab, ...
                    this.Session.hasRectangularLabels, ...
                    this.Session.HasFrameLabels);                
                enableShowLabelBoxes(this.AlgorithmTab, ...
                    this.Session.hasRectangularLabels, ...
                    this.Session.HasFrameLabels);                
                
                % Make alg section enabled only if labels exist and images are
                % loaded.
                enableAlgFlag = anyLabels && getNumImages(this.Session);
                enableAlgorithmSection(this.LabelTab,enableAlgFlag);
                
                % Enable export section
                enableExportSection(this.LabelTab,anyLabels)                
            else
                disableControls(this.LabelTab);
                disableControls(this.SemanticTab);
            end
            
            % Enable import annotations.
            enableImportAnnotationsButton(this.LabelTab, true);
            
            % Make frame label panel interactive if needed
            if this.Session.HasFrameLabels && getNumImages(this.Session)
                this.FrameLabelSetDisplay.unfreezeOptionPanel();
            else
                this.FrameLabelSetDisplay.freezeOptionPanel();
            end
            
            % Enable label definition save option if needed
            if anyLabels
                enableSaveLabelDefinitionsItem(this.LabelTab,true);
            else
                enableSaveLabelDefinitionsItem(this.LabelTab,false);
            end
            
            % Show Semantic Tab
            if ~hasPixelLabels(this.Session)
                hideContextualSemanticTab(this);
            end
        end
        
        %------------------------------------------------------------------
        function doAppActivated(this)
            if ~isvalid(this)
                return
            end
            % labelers should implement this
            if this.Session.HasROILabels && this.Session.hasImages()...
                    && strcmp(this.LabelTab.getModeSelection, 'ROI') && ~getTearAwayVisibility(this.SemanticTab)
                drawnow; % flush any pending callbacks before enableing drawing.
                this.GraphicsDisplay.enableDrawing();
            end
        end
        
        %------------------------------------------------------------------
        function doAppDeactivated(this)
            if ~isvalid(this)
                return
            end
             if this.Session.HasROILabels && this.Session.hasImages() ...
                     && strcmp(this.LabelTab.getModeSelection, 'ROI') && ~getTearAwayVisibility(this.SemanticTab)
                drawnow; % flush any pending callbacks before disabling drawing.
                 this.GraphicsDisplay.disableDrawing();
             end
        end
        
        %------------------------------------------------------------------
        function reset(this)
            [data, ~] = this.Session.readData(getCurrentIndex(this));
            resetPixelLabeler(this.GraphicsDisplay,data);
        end
    end
    
    %----------------------------------------------------------------------
    % Labeled Image Display Callbacks
    %----------------------------------------------------------------------
    methods (Access = protected)
        %------------------------------------------------------------------
        function doImageSelected(this, varargin)
            
            % Finalize any label information.
            finalize(this);
            
            evtData = varargin{2};
            
            % Do not draw on Multi-Selection
            if ~isempty(evtData.Index) && numel(evtData.Index) == 1
                this.drawImage(evtData.Index, false);
            end
        end
        
        %------------------------------------------------------------------
        function doImageRemoved(this, varargin)
            
            setWaiting(this.ToolGroup, true);
            
            % Finalize any label information.
            finalize(this);
            
            evtData = varargin{2};
            removedImageIndices = evtData.Index;
            
            if ~isempty(removedImageIndices)
                removeImagesFromSession(this.Session, removedImageIndices);

                % The pixel labeler needs to be reset since it contains stale
                % information about a image that was deleted. The newIdx chosen
                % is in sync with the method used to calculate the index when
                % selecting the image, in the event of images being removed.
                newIdx = min(max(removedImageIndices), getNumImages(this.Session));       
                if newIdx > 0
                    drawImage(this, newIdx, true);
                else
                    % Reset Image Browser Display
                    reset(this.GraphicsDisplay);
                    configure(this.GraphicsDisplay.ImagePanel, ...
                        @this.doModeChange, ...
                        @this.doDisableAppForDrawing, ...
                        @this.doEnableAppForDrawing, ...
                        @this.doStartAppWait, ...
                        @this.doFinishAppWait, ...
                        @this.doEnableGrabCutEditTools, ...
                        @this.doDisableGrabCutEditTools);
                    
                    % and reconfigure displays and drawing tools
                    resetDrawingTools(this.SemanticTab);
                    
                    % The labeling mode needs to be set since the 
                    % GraphicsDisplay is reset and the current
                    % Labeler information is empty. Also, the current label is
                    % selected, hence a label selection callback does not work
                    % here unless a new label is selected.
                    labelID = this.ROILabelSetDisplay.CurrentSelection;

                    if labelID > 0
                        % Query label information from session
                        roiLabel = this.Session.queryROILabelData(labelID);

                        setLabelingMode(this, roiLabel.ROI);

                        this.GraphicsDisplay.updateLabelSelection(roiLabel);

                    end
                end

                updateUI(this);
            end
            
            setWaiting(this.ToolGroup, false);
        end        
        
        %------------------------------------------------------------------
        function doImageRotate(this, varargin)
            % Rotate the image based on the context menu choice
            
            setWaiting(this.ToolGroup, true);
            
            % Finalize any label information.
            finalize(this);
            
            evtData = varargin{2};
            imagesToBeRotatedIdx = evtData.Index;
            rotationType = evtData.RotationType;
            
            if ~isempty(imagesToBeRotatedIdx)
                displayMessage = vision.getMessage('vision:imageLabeler:RotateImageWarning');
                dialogName = vision.getMessage('vision:imageLabeler:RotateImage');
                dlg = vision.internal.uitools.QuestDlg(this.getGroupName(), displayMessage, dialogName);
                wait(dlg);
                
                if dlg.IsYes
                    currentImageIdx = imagesToBeRotatedIdx(1);
                    rotatedImages = rotateImages(this.Session, imagesToBeRotatedIdx, rotationType);
                    
                    if ~isempty(find(rotatedImages==currentImageIdx, 1))
                        clearImage(this.GraphicsDisplay);
                        drawImage(this, currentImageIdx, true);
                    end
                    
                    numRotateImg = numel(rotatedImages);
                    numImgToBeRotated = numel(imagesToBeRotatedIdx);
                    if (numRotateImg > 0)  && numRotateImg < numImgToBeRotated
                        errorMessage = vision.getMessage('vision:imageLabeler:RotateImageErrorSome');
                        dialogName   = vision.getMessage('vision:imageLabeler:RotateImage');
                        dlg = vision.internal.uitools.ErrorDlg(this.getGroupName(), errorMessage, dialogName);
                        wait(dlg);
                    elseif numRotateImg == 0
                        errorMessage = vision.getMessage('vision:imageLabeler:RotateImageErrorAll');
                        dialogName   = vision.getMessage('vision:imageLabeler:RotateImage');
                        dlg = vision.internal.uitools.ErrorDlg(this.getGroupName(), errorMessage, dialogName);
                        wait(dlg);
                    end
                end
            end
            
            setWaiting(this.ToolGroup, false);
            
        end
        
        %------------------------------------------------------------------
        function drawImage(this, idx, forceRedraw)
            if ~hasImages(this.Session)
                return;
            end
            
            [data, exceptions] = this.Session.readData(idx);
            
            if ~isempty(exceptions)
                msg = sprintf('%s\n', exceptions(:).message);
                errorMessage = vision.getMessage('vision:imageLabeler:ReadDataError',msg);
                dialogName   = vision.getMessage('vision:imageLabeler:ReadDataErrorTitle');
                dlg = vision.internal.uitools.ErrorDlg(this.getGroupName(), errorMessage, dialogName);
                wait(dlg)                
            end
            
            data.ForceRedraw = forceRedraw;
            draw(this.GraphicsDisplay, data);
            
            % Update the Frame Label Display
            updateFrameLabelStatus(this.FrameLabelSetDisplay, data.SceneLabelIds);
            
            % Update legend display
            % Sync the image axes since a new image is drawn every time
            % an image is selected which blows off the previous axes
            syncImageAxes(this.GraphicsDisplay, this.LegendDisplay);
            if isSceneLabelBoxEnabled(this.LabelTab)
                show(this.LegendDisplay);
            end
            this.LegendDisplay.update(data.SceneLabelIds);
            
            % Update undo-Redo QAB to disable both.
            this.disableUndoRedoQAB();
        end
        
        %------------------------------------------------------------------
        function doLabelIsChanged(this, ~, data)
            % Handle ROI label changes for rectangles and pixel label
            % types.
            
            % Write label matrix to temp file
            if isa(data,'vision.internal.labeler.tool.PixelLabelEventData')
                
                % Update annotations and write label matrix only when there
                % are valid labelType.PixelLabel labels
                if hasPixelLabels(this.Session)
                    updatePixelLabelAnnotations(this, data.Data);
                end
                
                % Pixel Labels update Undo Redo QAB automatically.
            else
                updateROIsAnnotations(this, data.Data);
            end
        end
        
        %------------------------------------------------------------------
        function idx = getCurrentIndex(this)
            idx = getCurrentImageIndex(this.GraphicsDisplay);
        end
        
        %------------------------------------------------------------------
        function doFigKeyPress(this, ~, src)
            
            modifierKeys = {'control','command'};
            
            keyPressed = src.Key;
            modPressed = src.Modifier;
            
            if strcmp(modPressed, modifierKeys{ismac()+1})
                switch keyPressed
                    case 'a'
                        this.GraphicsDisplay.selectAllROIs();
                    case 'c'
                        this.GraphicsDisplay.copySelectedROIs();
                    case 'v'
                        this.GraphicsDisplay.pasteSelectedROIs();
                    case 'x'
                        this.GraphicsDisplay.cutSelectedROIs();
                    case 'y'
                        this.redo();
                    case 'z'
                        this.undo();
                    case 's'
                        this.saveSession();
                    case 'o'
                        this.loadSession();
                end
            else
                isAltPressed = strcmp(modPressed, 'alt');
                
                if isAltPressed
                    switch keyPressed
                        case 'uparrow'
                            this.FrameLabelSetDisplay.selectPrevItem();
                        case 'downarrow'
                            this.FrameLabelSetDisplay.selectNextItem();
                    end
                else
                    
                    switch keyPressed
                        case 'uparrow'
                            this.ROILabelSetDisplay.selectPrevItem()
                        case 'downarrow'
                            this.ROILabelSetDisplay.selectNextItem();
                        case {'rightarrow', 'leftarrow', 'home', 'end', 'pagedown', 'pageup'}
                            % navigate image browser. Does shift select
                            % behavior as well.
                            this.GraphicsDisplay.doBrowserKeyPress(src);
                        case {'delete','backspace'}
                            this.GraphicsDisplay.deleteSelectedROIs();
                        case 'return'
                            finalize(this);
                    end
                end
            end
        end
    end
    
    %----------------------------------------------------------------------
    % Undo-Redo methods
    %----------------------------------------------------------------------
    methods
        %------------------------------------------------------------------
        function undo(this, ~, ~)
            this.GraphicsDisplay.undo();
        end
        
        %------------------------------------------------------------------
        function redo(this, ~, ~)
            this.GraphicsDisplay.redo();
        end
    end
    
    %----------------------------------------------------------------------
    % ROI Label Definition Callbacks
    %----------------------------------------------------------------------
    methods
        
        function doROILabelAdditionCallback(this, varargin)
            
            % This callback handles the addition of a new ROI Label.
            
            % Launch ROI Label definition dialog
            dlg = vision.internal.labeler.tool.ROILabelDefinitionDialog(...
                this.getGroupName(),this.Session.ROILabelSet, this.SupportedROILabelTypes);
            
            % Set PixelLabelData as an invalid label name. It is reserved
            % for all pixel label in the groundTruth LabelData table.
            dlg.InvalidLabelNames = {'PixelLabelData'};
            
            wait(dlg);
            
            if ~dlg.IsCanceled
                
                % update session here
                roiLabel = dlg.getDialogData();
                
                if ~this.Session.isValidName( roiLabel.Label )
                    errorMessage = vision.getMessage('vision:labeler:LabelNameExistsDlgMsg',roiLabel.Label);
                    dialogName   = getString( message('vision:labeler:LabelNameExistsDlgName') );
                    errordlg(errorMessage, dialogName, 'modal');
                    return;
                end
                           
                if roiLabel.ROI == labelType.PixelLabel
                    % Determine pixel label id for new label.
                    roiLabel.PixelLabelID = this.Session.getPixelLabels();
                end
                
                % color is automatically generated inside
                roiLabel = this.Session.addROILabel(roiLabel);
                
                if this.ROILabelSetDisplay.NumItems == 0
                    hideHelperText(this.ROILabelSetDisplay);
                end
                
                % update display. When new items get added, it will become
                % the new selection.
                this.ROILabelSetDisplay.appendItem( roiLabel );
                this.ROILabelSetDisplay.selectLastItem();
            end
            
            this.updateUI();
        end
        
        function doROISublabelAdditionCallback(~, ~, ~)
        end
        
        function doROIAttributeAdditionCallback(~, ~, ~)
        end
        
        function doROIPanelItemModificationCallback(this, ~, data)
            % This callback is called when an ROI Label is modified.
            labelID = data.Index;
            roiLabel = this.Session.ROILabelSet.queryLabel(labelID);
            
            % Launch ROI Label definition dialog
            dlg = vision.internal.labeler.tool.ROILabelDefinitionDialog(...
                this.getGroupName(),roiLabel, this.SupportedROILabelTypes);
            wait(dlg);
            
            if ~dlg.IsCanceled
                
                % update session here
                roiLabel = dlg.getDialogData();
                
                % update display.
                this.ROILabelSetDisplay.modifyItemDescription(labelID, roiLabel);
                
                this.Session.ROILabelSet.updateLabelDescription(labelID, roiLabel.Description);
                this.Session.IsChanged = true;
            end
        end
        
        function doROIPanelItemDeletionCallback(this, ~, data)
            % This callback is called when an ROI Label is deleted.
             
            displayMessage = vision.getMessage('vision:labeler:DeletionDefinitionWarning', 'ROI');
            dialogName = 'Warning';
            dlg = vision.internal.uitools.QuestDlg(this.getGroupName(), displayMessage, dialogName);
            wait(dlg);
            
            if dlg.IsYes
                % Update session data
                labelID = data.Index;
                roiLabel = queryROILabelData(this.Session, labelID);
                
                if hasImages(this.Session) && roiLabel.ROI == labelType.PixelLabel
                    
                    finalize(this);
                    deletePixelLabelData(this.Session,roiLabel.PixelLabelID);
                    deletePixelLabelData(this.GraphicsDisplay,roiLabel.PixelLabelID);
                    
                end
                
                this.Session.deleteROILabel(labelID);
                
                % Update label display
                this.ROILabelSetDisplay.deleteItem(data);
                
                % Perform actions when a specifc ROI label is removed.
                %  * reset undo/redo and purge clipboard because these
                %    could hold mixed ROI labesl
                this.GraphicsDisplay.cleanupForROIRemoved(roiLabel.ROI);
                
                this.updateUI();
                
                % Update Display
                drawImage(this, this.getCurrentIndex(), false)      

            end
        end
        
        function doROIPanelItemSelectionCallback(this, varargin)
            % This callback is called when an ROI Label is selected
            labelID = this.ROILabelSetDisplay.CurrentSelection;
            
            % Query label information from session
            roiLabel = this.Session.queryROILabelData(labelID);
            
            % Set to Label Mode irrespective of what mode was chosen before
            setMode(this, 'ROI'); 
            
            setLabelingMode(this, roiLabel.ROI)
            
            isPixelLabel = roiLabel.ROI == labelType.PixelLabel;
            if ~isPixelLabel
                finalize(this);
            end
            
            this.updateUI();
            
            % Update undo/redo
            doUndoRedoUpdate(this, isPixelLabel);
            
            % Update label selection on video display
            this.GraphicsDisplay.updateLabelSelection(roiLabel);
        end
        
    end
    
    %----------------------------------------------------------------------
    % Frame Label Definition Callbacks
    %----------------------------------------------------------------------
    methods
        function doFrameLabelAdditionCallback(this, ~, ~)
            % This callback handles the addition of a new frame label.
            
            % Launch frame label definition dialog
            dlg = vision.internal.labeler.tool.FrameLabelDefinitionDialog(...
                this.getGroupName(),this.Session.FrameLabelSet);
            
            % PixelLabelData is reserved for all pixel label ROIs. 
            dlg.InvalidLabelNames = {'PixelLabelData'};
            
            wait(dlg);
            
            if ~dlg.IsCanceled
                
                frameLabel = dlg.getDialogData();
                
                if ~this.Session.isValidName( frameLabel.Label )
                    errorMessage = vision.getMessage('vision:labeler:LabelNameExistsDlgMsg',frameLabel.Label);
                    dialogName   = getString( message('vision:labeler:LabelNameExistsDlgName') );
                    dlg = vision.internal.uitools.ErrorDlg(this.getGroupName(), errorMessage, dialogName);
                    wait(dlg);
                    return;
                end
                
                % color is automatically generated inside.
                frameLabel = this.Session.addFrameLabel(frameLabel);
                
                if this.FrameLabelSetDisplay.NumItems<1
                    hideHelperText(this.FrameLabelSetDisplay);
                end
                
                % update display. When new items get added, it will become
                % the new selection.
                this.FrameLabelSetDisplay.appendItem( frameLabel );
                this.FrameLabelSetDisplay.selectLastItem();
                
                this.LegendDisplay.onLabelAdded(frameLabel.Label, frameLabel.Color);
                if getNumImages(this.Session) == 0
                    hide(this.LegendDisplay);
                end
            end
            
            this.updateUI();
        end
        
        function doFrameLabelSelectionCallback(~, varargin)
            % This callback is called when a Frame Label is selected.
            
            % TODO should this be removed?
        end
        
        function doFrameLabelModificationCallback(this, ~, data)
            % This callback is called when a Frame Label is modified.
            
            labelID = data.Index;
            frameLabel = this.Session.FrameLabelSet.queryLabel(labelID);
            
            % Launch frame label definition dialog
            dlg = vision.internal.labeler.tool.FrameLabelDefinitionDialog(...
                this.getGroupName(),frameLabel);
            wait(dlg);
            
            if ~dlg.IsCanceled
                
                frameLabel = dlg.getDialogData();
                
                % update display.
                this.FrameLabelSetDisplay.modifyItemDescription(labelID, frameLabel);
                
                this.LegendDisplay.onLabelModified(labelID, frameLabel.Label);
                
                this.Session.FrameLabelSet.updateLabelDescription(labelID, frameLabel.Description);
                this.Session.IsChanged = true;
            end
        end
        
        function doFrameLabelDeletionCallback(this, ~, data)
            % This callback is called when a Frame Label is deleted.
            
            sceneText = vision.getMessage('vision:labeler:Scene');
            displayMessage = vision.getMessage('vision:labeler:DeletionDefinitionWarning',sceneText);
            dialogName = vision.getMessage('vision:labeler:DeletionDefinitionWarningTitle');
            dlg = vision.internal.uitools.QuestDlg(this.getGroupName(), displayMessage, dialogName);
            wait(dlg);
            
            if dlg.IsYes
                labelID = data.Index;
                this.Session.deleteFrameLabel(labelID);
                this.FrameLabelSetDisplay.deleteItem( data );
                
                this.LegendDisplay.onLabelRemoved(labelID);
                
                this.updateUI();
            end
        end
        
        function doFrameLabelCallback(this, ~, data)
            % This callback is called when a user labels a frame or frame
            % interval.
            
            updateFrameLabelData(this, data, 'add');
        end
        
        function doFrameUnlabelCallback(this, ~, data)
            % This callback is called a user removes a frame label
            
            updateFrameLabelData(this, data, 'delete');
        end
        
        function updateFrameLabelData(this, data, addOrDelete)
            
            indices = this.GraphicsDisplay.SelectedImageIndex;
            
            frameLabel = this.Session.queryFrameLabelData(data.LabelID);
            
            % add to the session data
            for i = 1:numel(indices)
                switch addOrDelete
                    case 'add'
                        addFrameLabelAnnotation(this.Session, indices(i), frameLabel.Label);
                        this.FrameLabelSetDisplay.checkFrameLabel(data.LabelID);
                    case 'delete'
                        deleteFrameLabelAnnotation(this.Session, indices(i), frameLabel.Label);
                        this.FrameLabelSetDisplay.uncheckFrameLabel(data.LabelID);
                end
            end
            
            % Update status for current index
            [~,~,ids] = queryFrameLabelAnnotation(this.Session, indices(1));
            this.LegendDisplay.update(ids);
        end
        
    end
    
    %----------------------------------------------------------------------
    % Mode Change Callbacks
    %----------------------------------------------------------------------
    methods
        
        %------------------------------------------------------------------
        % When one of the mode buttons on the toolstrip is pressed, this
        % method updates the VideoDisplay to change mode.
        %------------------------------------------------------------------
        function setMode(this, mode)
            
            setMode@vision.internal.labeler.tool.LabelerTool(this, mode);
            % set focus back to image display
            resetFocus(this);
        end 
        
        %------------------------------------------------------------------
        function setLabelingMode(this, mode)
            setLabelingMode(this.GraphicsDisplay,mode);
            if mode == labelType.PixelLabel
                setROIIcon(this.LabelTab,'pixel');
                setROIIcon(this.SemanticTab,'pixel');
                showContextualSemanticTab(this);
                this.TabGroup.SelectedTab = getTab(this.SemanticTab);
            else
                setROIIcon(this.LabelTab,'roi');
                setROIIcon(this.SemanticTab,'roi');
                hideContextualSemanticTab(this);
            end
        end
        
        %------------------------------------------------------------------
        % When a mode change is requested through a context menu click,
        % this method will first take care of the toolstrip button updates
        % (press the appropriate mode button, unpress the others) and then
        % update the VideoDisplay to handle the changed mode.
        %------------------------------------------------------------------
        function doModeChange(this, ~, data)
            
            mode = data.Mode;
            this.ActiveTab.reactToModeChange(mode);
            
            % If there are no ROI labels, ignore the request to ROI mode.
            if ~this.Session.HasROILabels && strcmpi(mode, 'ROI')
                mode = 'none';
            end
            
            setMode(this, mode);
        end        
    end
    
    %----------------------------------------------------------------------
    % Export Callbacks
    %----------------------------------------------------------------------
    methods
        %------------------------------------------------------------------
        function exportLabelAnnotationsToWS(this)
            
            setWaiting(this.ToolGroup, true);
            
            resetWait = onCleanup(@()setWaiting(this.ToolGroup, false));
            
            finalize(this);

            %variableName  = 'gTruth';
            
            [file,path,indx] = uiputfile('label.png');
            
            filePath = getPixelLabelAnnotation(this.Session.ROIAnnotations,1);
            
            dst=fullfile(path,file);
            
            copyfile(filePath, dst)
            
            %this.Session.getPixelLabelDataPath
            
            %if hasPixelLabels(this.Session)
            %    dlgTitle = vision.getMessage('vision:uitools:ExportTitle');
            %    toFile = false;
            %    exportDlg = vision.internal.labeler.tool.ExportPixelLabelDlg(...
            %        this.getGroupName, variableName, dlgTitle, this.Session.getPixelLabelDataPath, toFile);
            %    wait(exportDlg);
            %    if ~exportDlg.IsCanceled
            %        this.Session.setPixelLabelDataPath(exportDlg.VarPath);
            %        TF = exportPixelLabelData(this.Session,exportDlg.CreatedDirectory);
             %       if ~TF
            %            errorMessage = getString( message('vision:labeler:UnableToExportDlgMessage') );
            %            dialogName   = getString( message('vision:labeler:UnableToExportDlgName') );
            %            dlg = vision.internal.uitools.ErrorDlg(this.getGroupName(), errorMessage, dialogName);
            %           wait(dlg);
            %            return;
            %        end
            %    end
                    
            %    format = 'groundTruth';
            %else
            %    allowTableFormatChoice = ~this.Session.hasSceneLabels();
            %    exportDlg = vision.internal.imageLabeler.tool.ExportDlg(this.getGroupName, variableName, allowTableFormatChoice);
            %    wait(exportDlg);
            %    format = exportDlg.VarFormat;
            %end
            
            %if ~exportDlg.IsCanceled
            %    varName = exportDlg.VarName;
            %    this.setStatusText(vision.getMessage('vision:labeler:ExportToWsStatus', varName));
                
            %    if strcmpi(format, 'groundTruth')
            %        labels = exportLabelAnnotations(this.Session);
            %        if hasPixelLabels(this.Session)
             %           refreshPixelLabelAnnotation(this.Session);
             %       end
             %       assignin('base', varName, labels);
             %       evalin('base', varName);
             %   else
                    % create table output
              %      labels = exportLabelAnnotations(this.Session);
              %      labels = labels.selectLabels(labelType.Rectangle);
              %      tbl = table(labels.DataSource.Source,'VariableNames', {'imageFilename'});
              %      tbl = [tbl labels.LabelData];
                    
              %      assignin('base', varName, tbl);
              %      evalin('base', varName);
               % end
               % this.setStatusText('');            
            %end
            drawnow;
            
            %TODO: refactor to share with GTL
        end

    end
    
    %----------------------------------------------------------------------
    % Load Callbacks
    %----------------------------------------------------------------------
    methods
        function loadImage(this)
           
            % Get image file names
            [fileNames, isUserCanceled] = imgetfile('MultiSelect', true);
            if isUserCanceled || isempty(fileNames)
                return;
            end
            
            doLoadImages(this, fileNames);
            
        end
        
        function loadImageFromDataStore(this)
           
            % Load images from a ImageDataStore variable in workspace
            variableTypes = {'matlab.io.datastore.ImageDatastore'};
            variableDisp =  {'ImageDatastore'};
            [imds,~,isCanceled] = vision.internal.uitools.getVariablesFromWS(variableTypes, variableDisp);
            
            if isCanceled
                return
            end
            
            if ~isempty(imds.Files)
                doLoadImages(this, imds.Files);
            end
        end
        
        function doLoadImages(this, fileNames)
            
            setWaiting(this.ToolGroup, true);
            
            this.setStatusText(vision.getMessage('vision:imageLabeler:LoadImageStatus'));
            
            turnOffWaiting = onCleanup(@()setWaiting(this.ToolGroup, false));
            
            uniqueImageFileNames = setdiff(unique(...
                [this.Session.ImageFilenames; reshape(fileNames,[],1)], 'stable'),...
                this.Session.ImageFilenames, 'stable');
            
            numImagesBeforeAdd = getNumImages(this.Session);
            
            % Add images to session
            addImagesToSession(this.Session, uniqueImageFileNames);
            
            numImagesAfterAdd = getNumImages(this.Session);
            
            % Select an Image to display
            if numImagesAfterAdd > numImagesBeforeAdd
                % Add images to the Browser
                imageData.Filenames = uniqueImageFileNames;
                appendImage(this.GraphicsDisplay, imageData);
                selectImageByIndex(this.GraphicsDisplay, numImagesBeforeAdd+1);
            end
            
            this.updateUI();
            
            this.setStatusText('');            
        end
    end
    
    %----------------------------------------------------------------------
    % Import Callbacks
    %----------------------------------------------------------------------
    methods
        
        function importLabelAnnotations(this, source)
            
            setWaiting(this.ToolGroup, true);
            
            this.setStatusText(vision.getMessage('vision:labeler:ImportLabelAnnotationsStatus'));
            
            setWaitingToFalseAtExit = onCleanup(@()setWaiting(this.ToolGroup, false));
            
            [success, gTruth] = importLabelAnnotationsPreWork(this, source);
             
            if ~success || isempty(gTruth)
                return;
            end
            
            % Validate gTruth            
            notValid = ~isscalar(gTruth) ...
                || ~isImageCollection(gTruth.DataSource);
            
            if notValid
                errorMessage = vision.getMessage('vision:imageLabeler:ImportLabelsInvalidGroundTruth');
                dialogName = vision.getMessage('vision:labeler:ImportError');
                dlg = vision.internal.uitools.ErrorDlg(this.getGroupName(), errorMessage, dialogName);
                wait(dlg);
                
                return;
            end
            
            [gTruth, ~] = splitRegularAndCustomLabels(this, gTruth);         
             
            isPixelLabelType = gTruth.LabelDefinitions.Type == labelType.PixelLabel;
            hasPixelLabels = any(isPixelLabelType);
            currentSessionHasPixelLabels = this.Session.hasPixelLabels;
            
            % canImportLabels 
            %   * always true if only rectangles
            %   * for pixel label, TRUE if existing pixel labels match
            %     those being imported or existing session has no pixels
            %     labels.
            currentDefinitions = exportLabelDefinitions(this.Session);
            
            canImportLabels = importPixelLabelHelper(this, gTruth, currentDefinitions);
            
            if ~canImportLabels
                return
            end
            
            assert(canImportLabels, 'Internal Error');
            
            % Merge gTruth into session. 
            %   * Rectangles are merged into existing session.
            %   * Pixel labels are only added if they match exactly the
            %     current set of pixel labels. IF there is any overlap
            %     between imported pixel label data and current session,
            %     then user is asked if they want to replace or keep
            %     originals.
            % 
             
            if hasImages(this.Session)
                % merge into session
                
                images = gTruth.DataSource.Source;
                currentImages = this.Session.ImageFilenames;
                labelData = gTruth.LabelData;
                
                % The the images in both current session and gTruth being
                % imported.
                [overlap, currentIndices, imageIdx] = intersect(currentImages, images, 'stable');
                
               
                % Should pixel lable data be replace or should the original
                % be kept. This is only required when existing session and
                % imported groundTruth have an overlap of image files.
                if hasPixelLabels && currentSessionHasPixelLabels

                    if ~isempty(overlap)
                        
                        replace = vision.getMessage('vision:labeler:ImportReplaceButtonPixelLabel');
                        keep    = vision.getMessage('vision:labeler:ImportKeepButtonPixelLabel');
                        cancel  = vision.getMessage('MATLAB:uistring:popupdialogs:Cancel');
                        dlgMessage = vision.getMessage('vision:labeler:ImportReplaceOrKeepPixelLabel');
                        dlgTitle   = vision.getMessage('vision:labeler:ImportReplaceOrKeepPixelLabelTitle');
                        selection = questdlg(dlgMessage, dlgTitle, ...
                            replace, keep, cancel, replace);
                        
                        if isempty(selection) % dialog was destroyed with a click
                            selection = cancel;
                        end
                        
                        switch selection
                            case replace
                                % nothing to do                           
                            case keep
                                % set all PixelLabelData for overlapping
                                % images to '' to keep originals.
                                labelData{imageIdx,'PixelLabelData'} = {''};
             
                            case cancel
                                % Abort import
                                return;
                        end                                        
                    end

                end
                
                % add new rectangle label definitions and scene labels.
                % pixel labels are always the same.
                
                % find unique rectangle/scene labels in gTruth to add to session.
                isRectOrScene = (gTruth.LabelDefinitions.Type == labelType.Rectangle) ...
                    | (gTruth.LabelDefinitions.Type == labelType.Scene);
                
                currentRectDef  = currentDefinitions(...
                    currentDefinitions.Type == labelType.Rectangle ...
                    | currentDefinitions.Type == labelType.Scene ,:);  
              
                rectOrSceneDefinitions = gTruth.LabelDefinitions(isRectOrScene,:);
                [~, idx]        = setdiff(rectOrSceneDefinitions.Name, currentRectDef.Name);
                newDefinitions  = rectOrSceneDefinitions(idx,:);
                
                if ~isempty(newDefinitions)
                    % only add if there are new rectangles to add.
                    addLabelsDefinitions(this.Session, newDefinitions);
                end
                
                % add new images
                [newImages, newIdx] = setdiff(images, currentImages, 'stable');
                
                newIndices = [];
                newData = [];
                if ~isempty(newImages)
                    
                    % this adds images and updates annotation structs to
                    % correct size.
                    newIndices = getNumImages(this.Session) + (1:numel(newImages));
                    addImagesToSession(this.Session, newImages);
                    newData = labelData(newIdx,:);
                   
                end
                
                labelDataForExistingImages = [];
                if ~isempty(currentIndices)
                    % data to update existing images with.
                    labelDataForExistingImages = labelData(imageIdx,:);
   
                end 
                
                % If data needs to be merged
                if ~isempty(newIndices)
                    labelData   = [labelDataForExistingImages; newData];
                    indices     = [currentIndices; newIndices];
                else
                    labelData   = labelDataForExistingImages;
                    indices     = currentIndices;
                end
                
                addLabelData(this.Session, gTruth.LabelDefinitions, labelData, indices);
           
                
            else
                % Add labels to blank session.
                this.Session.loadLabelAnnotations(gTruth);
            end
  
            reconfigureUI(this);
            
            drawImage(this, this.getCurrentIndex(), false);

            this.setStatusText('');
            
        end
        
        %------------------------------------------------------------------
        function reconfigureUI(this)
            % called after load session or import labels
            
            if hasImages(this.Session)
                this.GraphicsDisplay.loadImages(this.Session.ImageFilenames);
            end
            
            % Update the display with the Labels
            reconfigureROILabelSetDisplay(this);
            
            % Select first image.
            if hasImages(this.Session)
                selectImageByIndex(this.GraphicsDisplay, 1);
            end
            
            reconfigureFrameLabelSetDisplay(this);
            
            this.updateUI();
        end
    end
    
    %----------------------------------------------------------------------
    % Session Callbacks
    %----------------------------------------------------------------------
    methods
        function doLoadSession(this, pathName, fileName, varargin)
            
            % Indicate that this is going to take some time
            setWaiting(this.ToolGroup, true);
            
            % proceed with loading new session.
            loadedSession = this.SessionManager.loadSession(pathName, fileName);
            
            if isempty(loadedSession)
                setWaiting(this.ToolGroup, false);
                return;
            end
            
            
            % User has commited to load by not pushing cancel and the
            % current session is good to wipe.
            %
            % Delete Labels only after succesfully loading the
            % session. Otherwise, if the user cancels out from
            % loading the session their current labels will be
            % deleted.
            this.cleanSession();
            
            this.Session = loadedSession;
            
            % Set temp directory if session has pixel labels
            if hasPixelLabels(this.Session)
                setTempDirectory(this);
            end
            
            % Import any pixel label data
            TF = importPixelLabelData(this.Session);
            
            % If error importing pixel label data, prompt user for new
            % directory
            if ~TF
                oldDirectory = this.Session.TempDirectory;
                [~,name] = fileparts(tempname);
                foldername = vision.internal.labeler.tool.selectDirectoryDialog(name);
                setTempDirectory(this.Session,foldername);
                importPixelLabelData(this.Session);
                if isfolder(oldDirectory)
                    rmdir(oldDirectory,'s');
                end
            end
            
            reconfigureUI(this);
            
            % reconfigure drawing tools after loading session.
            if hasPixelLabels(this.Session)
                resetDrawingTools(this.SemanticTab);
            end
            
            % Set session file name as name in title bar of app
            [~, fileName] = fileparts(fileName);
            this.ToolGroup.Title = getString(message(...
                'vision:labeler:ToolTitleWithSession', this.ToolName, fileName));
            
            setWaiting(this.ToolGroup, false);
            
        end
        
        %------------------------------------------------------------------
        function newSession(this)
            
            % Indicate that this is going to take some time
            setWaiting(this.ToolGroup, true);
            
            this.setStatusText(vision.getMessage('vision:imageLabeler:NewSessionStatus'));
            
            % First check if we need to save anything before wiping the
            % existing data
            isCanceled = this.processSessionSaving();
            
            if isCanceled
                setWaiting(this.ToolGroup, false);
                return;
            end    
            
            this.cleanSession();
            
            this.setStatusText('');
            
            setWaiting(this.ToolGroup, false);
        end
        
        %------------------------------------------------------------------
        function cleanSession(this)
            % Reset labelling mode
            setMode(this, 'ROI');
            
            % Delete the current definitions
            deleteAllItemsLabelSetDisplay(this);
            
            % Reset Legend Display
            reset(this.LegendDisplay);
            
            % Reset Session
            resetSession(this.Session);
            
            % Reset Image Browser Display
            reset(this.GraphicsDisplay);
            configure(this.GraphicsDisplay.ImagePanel, ...
                @this.doModeChange, ...
                @this.doDisableAppForDrawing, ...
                @this.doEnableAppForDrawing, ...
                @this.doStartAppWait, ...
                @this.doFinishAppWait, ...
                @this.doEnableGrabCutEditTools, ...
                @this.doDisableGrabCutEditTools);
            
            % Reset Semantic Tab
            resetDrawingTools(this.SemanticTab);
            
            this.ToolGroup.Title = this.ToolName; 
            
            this.updateUI();
        end
        
    end
    
    %----------------------------------------------------------------------
    % Automation Callbacks
    %----------------------------------------------------------------------
    methods
        %------------------------------------------------------------------
        function setupSucceeded = setupAlgorithm(this)
            
            setWaiting(this.ToolGroup, true);
            
            try
                algorithm = this.AlgorithmSetupHelper.AlgorithmInstance;

                % Tell the algorithm which label definitions have been selected
                selections = getSelectedLabelDefinitions(this);
                setSelectedLabelDefinitions(algorithm, selections);
            
            % Check if user has completed algorithm setup
                setupSucceeded = verifyAlgorithmSetup(algorithm);
            catch ME
                % If there was an error, show the user what the error was
                % and abort.
                setWaiting(this.ToolGroup, false);
                
                dlgTitle = vision.getMessage('vision:labeler:CantVerifyAlgorithmTitle');
                showExceptionDialog(this, ME, dlgTitle);
                
                setupSucceeded = false;
                return;
            end
            
            % If setup failed, tell the user their setup is incomplete and
            % abort.
            if ~setupSucceeded
                
                setWaiting(this.ToolGroup, false);
                
                %Launch dialog stating setup is incomplete
                errorMessage = vision.getMessage('vision:labeler:IncompleteAlgorithmSetupMessage');
                dialogName = vision.getMessage('vision:labeler:IncompleteAlgorithmSetupTitle');
                dlg = vision.internal.uitools.ErrorDlg(this.getGroupName(), errorMessage, dialogName);
                wait(dlg);
                
                return;
            end
            
            setWaiting(this.ToolGroup, false);
        end
        
        %------------------------------------------------------------------
        function runAlgorithm(this)
            
            %--------------------------------------------------------------
            % Do Verify Setup and Initialize
            %--------------------------------------------------------------
            
            finalize(this);
            
            closeExceptionDialogs(this);
            
            algorithm = this.AlgorithmSetupHelper.AlgorithmInstance;
            
            % Disable all UI interactions (except the algorithm tab)
            % while algorithm is running.
            freezePanelsWhileRunningAlgorithm(this);
            
            % However the algorithm run goes, exit cleanly (including
            % CTRL+C).
            onDone = onCleanup(@this.cleanupPostAlgorithmRun);

            this.StopAlgRun = false;
            
            % Freeze browser interactions
            freezeBrowserInteractions(this.GraphicsDisplay);
            
            % Freeze drawing tools
            freezeDrawingTools(this.GraphicsDisplay);
            
            % Get indices of images to automate over
            imageIndices = this.GraphicsDisplay.VisibleImageIndices;
            
            % Display first image
            firstImageIndex = imageIndices(1);
            this.GraphicsDisplay.selectImageByIndex(firstImageIndex);
            
            % Run algorithms initialize() method on the first image
            success = initializeAlgorithm(this, firstImageIndex);
            
            if ~success
                return;
            end
            
            %--------------------------------------------------------------
            % Do Run
            %--------------------------------------------------------------
            
            % make the display behave correctly when the algorithm iterates
            % through images.
            this.GraphicsDisplay.algorithmRunSetup()
            teardown = onCleanup(@()this.GraphicsDisplay.algorithmRunTearDown());
            
            for idx = imageIndices
                
                if this.StopAlgRun
                    % User clicked stop, execute terminate and exit.
                    break;
                end
                
                this.GraphicsDisplay.selectImageByIndex(idx);

                % Read image
                data = this.Session.readData(idx);
                I = data.Image;
                imSize = [size(I,1) size(I,2)];
                % Run user algorithm and retrieve labels
                try
                    [labels,isValid] = doRun(algorithm, I);
                    labels = checkUserLabels(this, labels, isValid, imSize);
                    labels = restructPositionAndAddUID(this, labels);
                catch ME
                    dlgTitle = vision.getMessage('vision:labeler:CantRunAlgorithmTitle');
                    showExceptionDialog(this, ME, dlgTitle);
                    return;
                end
                
                % Add to session
                this.Session.addAlgorithmLabels(idx, labels);
                
                % Update display
                reset(this);
                drawImage(this, idx, false);
                drawnow('limitrate')
            end


            %--------------------------------------------------------------
            % Terminate
            %--------------------------------------------------------------
            try
                terminate(algorithm);
            catch ME
                dlgTitle = vision.getMessage('vision:labeler:CantTerminateAlgorithmTitle');
                showExceptionDialog(this, ME, dlgTitle);
                return;
            end
            
        end
        
        %------------------------------------------------------------------
        function userCanceled = undorunAlgorithm(this)
            
            userCanceled = showUndoRunDialog(this);
            
            if ~userCanceled
                
                closeExceptionDialogs(this);
                finalize(this);
                
                setWaiting(this.ToolGroup, true);
                
                imageIndices = this.GraphicsDisplay.VisibleImageIndices;
                replaceAnnotationsForUndo(this.Session, imageIndices);
                
                if hasPixelLabels(this.Session)
                    replacePixelLabels(this.Session,imageIndices);
                end
                
                reset(this);
                
                % Display first image
                this.GraphicsDisplay.selectImageByIndex(imageIndices(1));
                
                % Draw the image since the display will not fire an event
                % upon selection since only one image exists in the browser
                % display and it has already been selected
                if imageIndices == 1
                    drawImage(this, imageIndices(1), false);
                end
                
                setWaiting(this.ToolGroup, false);
            end
        end
        
        %------------------------------------------------------------------
        function acceptAlgorithm(this)
            
            closeExceptionDialogs(this);
            finalize(this);
            
            % Save automation results
            imageIndices = this.GraphicsDisplay.VisibleImageIndices;
            
            mergeAnnotations(this.Session, imageIndices);
            
            if hasPixelLabels(this.Session)
                mergePixelLabels(this.Session,imageIndices);
            end
            
            removeInstructionsPanel(this);
            
            endAutomation(this);
        end
        
    end
    
    methods
        %------------------------------------------------------------------
        function success = tryToSetupAlgorithm(this)
            % Before opening the algorithm tab, check the following:
            %   * Is an algorithm selected?
            %   * Is the selected algorithm on path?
            %   * Is the algorithm valid?
            %
            % Once these checks are made, instantiate the algorithm and
            % check that there are consistent labels for the automation
            % algorithm. Update the label panels and video display.
            
            % Close any exception dialogs
            closeExceptionDialogs(this);
            
            % Show spinning wheel
            setWaiting(this.ToolGroup, true);
            
            oCU = onCleanup(@()setWaiting(this.ToolGroup, false));
            
            success         = false;
            
            % Make sure an algorithm is selected
            if ~this.LabelTab.isAlgorithmSelected
                errorMessage = vision.getMessage('vision:labeler:SelectAlgorithmFirst');
                dialogName = vision.getMessage('vision:labeler:SelectAlgorithmFirstTitle');
                
                dlg = vision.internal.uitools.ErrorDlg(this.getGroupName(), errorMessage, dialogName);
                wait(dlg);
                return;
            end
            
            try
                % Make sure the algorithm is on path, help the user with path
                % set up if needed.
                if ~isAlgorithmOnPath(this.AlgorithmSetupHelper)
                    return;
                end

                % Make sure the algorithm is a valid AutomationAlgorithm class.
                if ~isAlgorithmValid(this.AlgorithmSetupHelper)
                    return;
                end

                % Instantiate the algorithm.
                if ~instantiateAlgorithm(this.AlgorithmSetupHelper)
                    return;
                end
            
            catch ME
                
                dlgTitle = vision.getMessage('vision:labeler:CantSetupAlgorithmTitle');
                showExceptionDialog(this, ME, dlgTitle);
                
                return;
            end
            
            % Populate GroundTruth
            finalize(this);
            gTruth = exportLabelAnnotations(this.Session);
            setAlgorithmLabelData(this.AlgorithmSetupHelper, gTruth);
            
            % Make sure label definitions in the app are consistent with
            % what the app expects.
            [roiLabelDefs,frameLabelDefs] = getLabelDefinitions(this.Session);
            if ~checkValidLabels(this.AlgorithmSetupHelper, roiLabelDefs, frameLabelDefs)
                return;
            end
            
            % Set up folder for automation pixel label data
            if hasPixelLabels(this.Session)
                newdir = fullfile(this.Session.TempDirectory,'Automation');
                status = mkdir(newdir);
                if status
                    setTempDirectory(this.Session,newdir)
                else
                    return;
                end
            end
            
            % Setup is complete! If we reach this point, algorithm setup
            % was successful.
            success = true;
            
            % Update ROI and Frame Label Panels.
            freezeLabelPanels(this);
            
            % Update Current Display
            reset(this);
            
            % Update image list display
            filterSelectedImages(this.GraphicsDisplay);
            
            % Cache annotations
            cacheAnnotations(this.Session);
            
            % Update Session to only those labels that are part of the
            % algorithm run
            imageIndices        = this.GraphicsDisplay.VisibleImageIndices;
            validFrameLabels    = this.AlgorithmSetupHelper.ValidFrameLabelNames;
            replaceAnnotations(this.Session, imageIndices, validFrameLabels);
            
            % Update image display
            this.GraphicsDisplay.selectImageByIndex(imageIndices(1));
            
            % Refresh frame label display
            [~,~,labelIDs] = this.Session.queryFrameLabelAnnotation(imageIndices(1));
            updateFrameLabelStatus(this.FrameLabelSetDisplay, labelIDs);
            this.LegendDisplay.update(labelIDs);
        end
        
        %------------------------------------------------------------------
        function cleanupPostAlgorithmRun(this)
            
            % Stop running the algorithm
            this.StopAlgRun = true;
            
            % Restore browser interactions
            unfreezeBrowserInteractions(this.GraphicsDisplay);
            
            % Restore image display interactions
            unfreezeDrawingTools(this.GraphicsDisplay);
            unfreezePanelsAfterRunningAlgorithm(this);
        end
        
        %------------------------------------------------------------------
        function userCanceled = showUndoRunDialog(this)
            
            % Check settings
            s = settings;
            showUndoRun = s.vision.imageLabeler.ShowUndoRunDialog.ActiveValue;
            
            if ~showUndoRun
                userCanceled = false;
                return;
            end
            
            userCanceled = vision.internal.labeler.tool.undoRunDialog(getGroupName(this), this.InstanceName);
        end
        
        %------------------------------------------------------------------
        function success = initializeAlgorithm(this, imageIndex)
            
            success = true;
            
            setWaiting(this.ToolGroup, true);
            
            data = this.Session.readData(imageIndex);
            I = data.Image;
            
            algorithm = this.AlgorithmSetupHelper.AlgorithmInstance;
            
            try
                doInitialize(algorithm, I);
            catch ME
                success = false;
                
                dlgTitle = vision.getMessage('vision:labeler:CantInitializeAlgorithmTitle');
                showExceptionDialog(this, ME, dlgTitle);
                return;
            end
            
            setWaiting(this.ToolGroup, false);
        end
        
        %------------------------------------------------------------------
        function endAutomation(this)
            
            endAutomation@vision.internal.labeler.tool.LabelerTool(this);
            
            % Specialize for ImageLabelerTool.
            % Update image display
            reset(this);
            restoreAllImages(this.GraphicsDisplay);
            drawImage(this, this.getCurrentIndex(), false);
            
            setSemanticTabForAutomation(this);
        end
        
    end
    
end
