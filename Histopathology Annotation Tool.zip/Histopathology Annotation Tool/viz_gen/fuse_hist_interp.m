[file,path]  = uigetfile(".png","Select Histology Annotation");

hist=imread(fullfile(path,file));
[file,path]  = uigetfile(".png","Select Interpolated Annotation");
interp=imread(fullfile(path,file));
[file,path]  = uigetfile(".jpg","Select Whitelight Image");
raw=imread(fullfile(path,file));



labelIDs = [1,2];
labelcats = cellstr(["Cancer" "Healthy"]);




diff=interp-hist;


cats = categorical(diff,labelIDs,labelcats);
cats_hist=categorical(hist,labelIDs,labelcats);

im=labeloverlay(raw,cats,"colormap","lines");


bla=labeloverlay(im,cats_hist,"colormap","lines","Transparency",0.05);

imshow(bla)





