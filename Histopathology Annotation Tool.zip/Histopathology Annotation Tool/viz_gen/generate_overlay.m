
[file,path]  = uigetfile(".mat","Select Labels File");

if file==0
    return;
end

load(fullfile(path,file),["definitions"]);

ID=definitions.PixelLabelID;
ID=cell2mat(ID);



[file,path]  = uigetfile(".png","Select Label Image");

if file==0
    return;
end



buildingLabels = imread(fullfile(path,file));
cats = categorical(buildingLabels,ID);

[file,path]  = uigetfile(".jpg","Select White Light Image");

if file==0
    return;
end

im=imread(fullfile(path,file));




[file,path,indx] = uiputfile('overlay.png');

if file==0
    return;
end

im=labeloverlay(im,cats,"colormap","lines");
imwrite(im,fullfile(path,file));
figure;
imshow(im);